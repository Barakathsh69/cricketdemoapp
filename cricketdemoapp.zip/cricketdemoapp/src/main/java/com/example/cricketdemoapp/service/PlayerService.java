package com.example.cricketdemoapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cricketdemoapp.entity.PlayerEntity;
import com.example.cricketdemoapp.repository.PlayerRepository;

@Service
public class PlayerService {

	@Autowired
	private PlayerRepository playerRepository;

	public PlayerEntity savePlayers(PlayerEntity players) {
		return playerRepository.save(players);
	}

	public List<PlayerEntity> getAllPlayers() {
		return (List<PlayerEntity>) playerRepository.findAll();
	}

	public Optional<PlayerEntity> getSelectedPlayer(long id) {
		return playerRepository.findById(id);
	}

	public PlayerEntity updatePlayer(PlayerEntity player) {
		return playerRepository.save(player);
	}

	public void deletePlayer(long id) {
		playerRepository.deleteById(id);

	}

}
