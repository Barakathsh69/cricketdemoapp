package com.example.cricketdemoapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.cricketdemoapp.entity.PlayerEntity;


public interface PlayerRepository extends CrudRepository<PlayerEntity, Long> {

}
