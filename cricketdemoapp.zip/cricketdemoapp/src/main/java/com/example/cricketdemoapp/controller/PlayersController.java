package com.example.cricketdemoapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.cricketdemoapp.entity.PlayerEntity;
import com.example.cricketdemoapp.service.PlayerService;


@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
public class PlayersController {

	@Autowired
	private PlayerService playerService;

	@GetMapping(value = "/")
	public String helloMessage() {
		return "Hello ";
	}

	@PostMapping(value = "/addplayer")
	public PlayerEntity savePlayer(@RequestBody PlayerEntity players) {
		PlayerEntity playerEntity = null;
		if (players != null) {
			playerEntity = playerService.savePlayers(players);
		}
		return playerEntity;
	}

	@GetMapping("/viewplayers")
	public List<PlayerEntity> getAllPlayers() {
		return playerService.getAllPlayers();
	}

	@GetMapping("/selectedplayer/{id}")
	public Optional<PlayerEntity> getSelectedPlayer(@PathVariable("id") long id) {
		return playerService.getSelectedPlayer(id);
	}

	@PutMapping(value = "/updateplayer")
	public PlayerEntity updatePlayer(@RequestBody PlayerEntity player) {
		return playerService.updatePlayer(player);
	}

	@GetMapping(value = "/deleteplayer/{id}")
	public List<PlayerEntity> deletePlayer(@PathVariable("id") long id) {
		playerService.deletePlayer(id);
		return getAllPlayers();
	}

}
